class Fridge < ApplicationRecord
    has_one_attached :image
end
