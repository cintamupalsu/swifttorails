module FridgesHelper
end
